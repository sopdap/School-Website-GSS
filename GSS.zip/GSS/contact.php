<?php include('shared/page_header.php'); ?>
<?php 

//error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "gssdb";
// Create connection
$output ="";
if(isset($_POST['submit'])){
$conn = new mysqli($servername, $username, $password, $dbName);

$senderName = $_POST['senderName'];
$emailAddress = $_POST['emailAddress'];
$contactPhoneNumber = $_POST['contactPhoneNumber'];
$subject = $_POST['subject'];
$message = $_POST['message'];


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO contact (senderName, emailAddress, contactPhoneNumber, subject, message)
VALUES ('$senderName', '$emailAddress', '$contactPhoneNumber', '$subject', '$message')";

if (mysqli_query($conn, $sql)) {   	


  	//echo ('applicationdetails.php?id=' . h(u($application['application_id']))); 

    $output = "Application sumbitted successfullly" . "<a href ='index.php'>Click Here to Go back Home</a>";
   ///Redirect_to(url_for('/applicationdetails.php?id=' . $new_id)); die; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}

?>

		<header id="head" class="secondary">
            <div class="container">
                    <h1>Contact Us</h1>
                    <p>it is our joy to here from you!</p>
                </div>
    </header>


	<!-- container -->
	<div class="container">
				<div class="row">
					<div class="col-md-8">
						<h3 class="section-title">Your Message</h3>
						
						<form class="form-light mt-20" role="form" action="contact.php" method="post">
							<div class="form-group">
								<label>Name</label>
								<input type="text" class="form-control" placeholder="Your name" name="senderName">
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Email</label>
										<input type="email" class="form-control" placeholder="Email address" name="emailAddress">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Phone</label>
										<input type="text" class="form-control" placeholder="Phone number" name="contactPhoneNumber">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label>Subject</label>
								<input type="text" class="form-control" placeholder="Subject" name="subject">
							</div>
							<div class="form-group">
								<label>Message</label>
								<textarea class="form-control" id="message" placeholder="Write you message here..." style="height:100px;" name="message"></textarea>
							</div>
							<button type="submit" class="btn btn-two" name="submit">Send message</button><p><br/></p>
						</form>
					</div>
					<div class="col-md-4">
						<div class="row">
							<div class="col-md-6">
								<h3 class="section-title">Our Location</h3>
								<div class="contact-info">
									<h5>Address</h5>
									<p>Along Jos Road, Ombi 1, Lafia</p>
									
									<h5>Email</h5>
									<p>adminssion@gsslafia.com</p>
									
									<h5>Phone</h5>
									<p>+2348160413494</p>
									<h5>Post Address</h5>
									<p>PMB BOX 1234567</p>
								</div>
							</div> 
						</div> 						
					</div>
				</div>
			</div>
	<!-- /container -->
  <?php include('shared/footer.php'); ?>


	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>

	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	<script src="assets/js/google-map.js"></script>


</body>
</html>
