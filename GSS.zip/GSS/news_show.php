<?php  require_once ('private/initialize.php'); ?>
<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Dashboard';

?>
<?php include( 'shared/news_header.php'); ?>
    <header id="head" class="secondary">
                <div class="container">
                        <h1>Notice Board </h1>
                        <p> Welcome Back Admin</p>
                    </div>
        </header>
<div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="banner-inner-page">

  </div>
  <!--//banner -->
  <!--/single-->
  <div class="container">
 <br>

<?php
// $id = isset($_GET['id']) ? $_GET['id'] : '1';
$id = $_GET['id'] ?? '1'; // PHP > 7.0

$news = find_news_by_id($id);

?>

<?php $page_title = 'Show Page'; ?>
<div id="content">

  
  <div class="page show">

    <h1>Heading: <?php echo h($news['heading']); ?> </h1> 
    <?php echo "<br />";?>
    <p><?php echo h($news['message']); ?></p>

  <a class="back-link" href="<?php echo ('news.php'); ?>">&laquo; Back to News List</a>
  </div>

</div>

 <?php include('shared/footer.php'); ?>
