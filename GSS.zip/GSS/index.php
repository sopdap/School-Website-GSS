<?php include('shared/main_header.php'); ?>
  <div class="container">
    <div class="row">
					<div class="col-md-3">
						<div class="grey-box-icon">
							<div class="icon-box-top grey-box-icon-pos">
								<img src="assets/images/1.png" alt="" />
							</div><!--icon box top -->
							<h4>Welcome To Government Secondary school Lafia</h4>
							<p>The home of Excellent knowledge, where student are train to be a leader.</p>
						</div><!--grey box -->
					</div><!--/span3-->
					<div class="col-md-3">
						<div class="grey-box-icon">
							<div class="icon-box-top grey-box-icon-pos">
								<img src="assets/images/2.png" alt="" />
							</div><!--icon box top -->
							<h4>Meet our Staff</h4>
							<p>In government secondary school we standard Teachers who are capable of teaching your children and also take care of them so my dear parents dont be afarid of meeting our staff for anthing thanks.</p>
						</div><!--grey box -->
					</div><!--/span3-->
					<div class="col-md-3">
						<div class="grey-box-icon">
							<div class="icon-box-top grey-box-icon-pos">
								<img src="assets/images/3.png" alt="" />
							</div><!--icon box top -->
							<h4>Latest Updates</h4>
							<p>There will a P.A.T meeting this coming week in government secondary school, please all parents should be in attendance in oder for us to dicuss on how to organize the end of the party for outgoing students.</p>
						</div><!--grey box -->
					</div><!--/span3-->
					<div class="col-md-3">
						<div class="grey-box-icon">
							<div class="icon-box-top grey-box-icon-pos">
								<img src="assets/images/4.png" alt="" />
							</div><!--icon box top -->
							<h4>Decipline</h4>
							<p>We Teach, an applied the wisdom of God to make your word stand out.</p>
						</div><!--grey box -->
					</div><!--/span3-->
				</div>
    </div>
      
   
  
	
      <section class="container">
      <div class="row">
      	<div class="col-md-8"><div class="title-box clearfix "><h2 class="title-box_primary">About Us</h2></div> 
        <p><span>More so, it not something new to see universities and other higher institutions complaining that some of the students admitted on the basis of their grades in WAEC examination and high grades in JAMB examination are asked to withdraw from the institution because of their academic deficiency and resultant inability to understand the lectures. </span></p>
        <p>These are undoubtedly the ones who cheated in these examination, those who really work hard and pass the examination without cheating have no problem academically in the higher institutions. Thus, when these ones get jobs, perhaps through fraudulent ways, they cannot perform well. That is, they are those that defraud their companies of millions of naira..</p>
        <a href="#" title="read more" class="btn-inline " target="_self">read more</a> </div>
              
          
          <div class="col-md-4"><div class="title-box clearfix "><h2 class="title-box_primary">Up Coming Event</h2></div> 
            <div class="list styled custom-list">
            <ul>
            <li><a title=" PTA Meeting." href="news.php">PTA Meeting</a></li>
            <li><a title=" " href="#">Chrismas Carol 2019</a></li>
            <li><a title=" " href="#">Philosophy and Modern Languages</a></li>
            <li><a title=" " href="#">History (Ancient and Modern)</a></li>
            <li><a title="." href="#">Classical Archaeology and Ancient History</a></li>
            <li><a title="Fusce feugiat malesuada odio. Morbi nunc odio gravida at cursus nec luctus." href="#">Human Anatomy</a></li>
            </ul>
            </div>
         </div>
      </div>
      </section>
      
    	 
     <?php include('shared/footer.php'); ?>

	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="assets/js/modernizr-latest.js"></script> 
	<script type='text/javascript' src='assets/js/jquery.min.js'></script>
    <script type='text/javascript' src='assets/js/fancybox/jquery.fancybox.pack.js'></script>
    
    <script type='text/javascript' src='assets/js/jquery.mobile.customized.min.js'></script>
    <script type='text/javascript' src='assets/js/jquery.easing.1.3.js'></script> 
    <script type='text/javascript' src='assets/js/camera.min.js'></script> 
    <script src="assets/js/bootstrap.min.js"></script> 
	<script src="assets/js/custom.js"></script>
    <script>
		jQuery(function(){
			
			jQuery('#camera_wrap_4').camera({
                transPeriod: 500,
                time: 3000,
				height: '600',
				loader: 'false',
				pagination: true,
				thumbnails: false,
				hover: false,
                playPause: false,
                navigation: false,
				opacityOnGrid: false,
				imagePath: 'assets/images/'
			});

		});
      
	</script>
    
</body>
</html>
