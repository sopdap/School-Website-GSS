<?php

  // Subjects

  function find_all_children() {
    global $db;

    $sql = "SELECT * FROM register_child ";
    $sql .= "ORDER BY Level ASC";
  
	$result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_children_by_id($id) {
    global $db;

    $sql = "SELECT * FROM register_child ";
    $sql .= "WHERE id='" . $id . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $register_child = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $register_child; // returns an assoc. array
  }
  
  function insert_children($register_child) {
    global $db;

    $sql = "INSERT INTO register_child ";
    $sql .= "(child_surname, other_name, maiden_name, child_gender, dateOfBirth, stateOfOrigin, localGovernment, AddmittedYear, childImage, NK_firstName, NK_lastName, NK_relationship, NK_contactAddress, NK_emailAddress, NK_phoneNumber, NK_gender, ) ";
    $sql .= "VALUES (";
	$sql .= "'" . $register_child['child_surname'] . "',";
    $sql .= "'" . $register_child['other_name'] . "',";
    $sql .= "'" . $register_child['maiden_name'] . "'";
	$sql .= "'" . $register_child['child_gender'] . "'";
	$sql .= "'" . $register_child['dateOfBirth'] . "'";
	$sql .= "'" . $register_child['stateOfOrigin'] . "'";
	$sql .= "'" . $register_child['localGovernment'] . "'";
	$sql .= "'" . $register_child['AddmittedYear'] . "'";
	$sql .= "'" . $register_child['childImage'] . "'";
	$sql .= "'" . $register_child['NK_firstName'] . "'";
	$sql .= "'" . $register_child['NK_lastName'] . "'";
	$sql .= "'" . $register_child['NK_relationship'] . "'";
	$sql .= "'" . $register_child['NK_contactAddress'] . "'";
	$sql .= "'" . $register_child['NK_emailAddress'] . "'";
	$sql .= "'" . $register_child['NK_phoneNumber'] . "'";
	$sql .= "'" . $register_child['NK_gender'] . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
  
    if($result) {
      return true;
    } else {
      // INSERT failed
     echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
	}
