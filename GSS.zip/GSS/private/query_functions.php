<?php

  // Student

  function find_all_children() {
    global $db;

    $sql = "SELECT * FROM register_child ";
    $sql .= "ORDER BY child_id ASC";
  
	$result = mysqli_query($db, $sql);
    confirm_result_set($result);

    return $result;
  }

  function find_children_by_id($id) {
    global $db;
    $sql = "SELECT * FROM register_child ";
    $sql .= "WHERE child_id='" . $id . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $register_child = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $register_child; // returns an assoc. array
  }



  //display contact record
   function find_all_contact() {
    global $db;

    $sql = "SELECT * FROM contact ";
    $sql .= "ORDER BY contact_id ASC";
  
  $result = mysqli_query($db, $sql);
    confirm_result_set($result);

    return $result;
  }

  function find_contact_by_id($id) {
    global $db;
    $sql = "SELECT * FROM contact ";
    $sql .= "WHERE contact_id='" . $id . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $contact = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $contact; // returns an assoc. array
  }
  
  //application retreiveing  method
  function find_all_application() {
    global $db;

    $sql = "SELECT * FROM application ";
    $sql .= "ORDER BY applicationid ASC";
  
  $result = mysqli_query($db, $sql);
    confirm_result_set($result);

    return $result;
  }

  function find_application_by_id($id) {
    global $db;
    $sql = "SELECT * FROM application ";
    $sql .= "WHERE applicationid ='" . $id . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $contact = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $contact; // returns an assoc. array
  }
  
  function find_all_news() {
    global $db;

    $sql = "SELECT * FROM new ";
    $sql .= "ORDER BY new_id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    
     //echo $sql;
    confirm_result_set($result);
    return $result;
  }

  function find_news_by_id($id) {
    global $db;

    $sql = "SELECT * FROM new ";
    $sql .= "WHERE new_id='" . db_escape($db, $id) . "'";
     //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $news = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $news; // returns an assoc. array
  }


  ///function for add record
  function insert_children ($register_child) {
    global $db;
    $sql = "INSERT INTO register_child ";
    $sql .= "(child_surname, other_name, maiden_name, child_gender, dateOfBirth, stateOfOrigin, localGovernment, AddmittedYear, childImage, NK_firstName, NK_lastName, NK_relationship, NK_contactAddress, NK_emailAddress, NK_phoneNumber, NK_gender) ";
  $sql .= "VALUES (";
	$sql .= "'" . $register_child['child_surname'] . "',";
  $sql .= "'" . $register_child['other_name'] . "',";
  $sql .= "'" . $register_child['maiden_name'] . "',";
	$sql .= "'" . $register_child['child_gender'] . "',";
	$sql .= "'" . $register_child['dateOfBirth'] . "',";
	$sql .= "'" . $register_child['stateOfOrigin'] . "',";
	$sql .= "'" . $register_child['localGovernment'] . "',";
	$sql .= "'" . $register_child['AddmittedYear'] . "',";
	$sql .= "'" . $register_child['childImage'] . "',";
	$sql .= "'" . $register_child['NK_firstName'] . "',";
	$sql .= "'" . $register_child['NK_lastName'] . "',";
	$sql .= "'" . $register_child['NK_relationship'] . "',";
	$sql .= "'" . $register_child['NK_contactAddress'] . "',";
	$sql .= "'" . $register_child['NK_emailAddress'] . "',";
	$sql .= "'" . $register_child['NK_phoneNumber'] . "',";
	$sql .= "'" . $register_child['NK_gender'] . "',";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
  
    if($result) {
      return true;
    } else {
      // INSERT failed
     //echo $sql;
	 echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
	}
	

  function update_children($register_child) {
    global $db;

    $sql = "UPDATE register_child SET ";
    
	$sql .= "FirstName='" . $student['FirstName'] . "', ";
	$sql .= "MiddleName='" . $student['MiddleName'] . "', ";
	$sql .= "LastName='" . $student['LastName'] . "', ";
  $sql .= "RegNumber='" . $student['RegNumber'] . "', ";
	$sql .= "Level='" . $student['Level'] . "', ";
	$sql .= "Gender='" . $student['Gender'] . "', ";
	$sql .= "ContactAddress='" . $student['ContactAddress'] . "', ";
	$sql .= "AddmittedYear='" . $student['AddmittedYear'] . "', ";
	$sql .= "DOB='" . $student['DOB'] . "', ";
	$sql .= "email='" . $student['email'] . "', ";
	$sql .= "PhoneNumber='" . $student['PhoneNumber'] . "', ";
	$sql .= "StateOfOrigin='" . $student['StateOfOrigin'] . "', ";
	$sql .= "LGA='" . $student['LGA'] . "', ";
	$sql .= "NameOfKin='" . $student['NameOfKin'] . "', ";
	$sql .= "NextOfKinStatus='" . $student['NextOfKinStatus'] . "', ";
	$sql .= "PhoneNumber='" . $student['PhoneNumber'] . "', ";
  $sql .= "NextOfKinAddress='" . $student['NextOfKinAddress'] . "' ";
  $sql .= "WHERE id='" . $student['id'] . "' ";
  $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_children($id) {
    global $db;

    $sql = "DELETE FROM register_child ";
    $sql .= "WHERE child_id='" . $id . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  //staff functions 
   
  
 function insert_to_staff($staff) {
	global $db;
	
  $sql = "INSERT INTO staff ";
  $sql .= "(staff_number, F_Name, Email, PhoneNumber, Qualification, Gender, ContactAddress, DOB, DateEmployee, salary, CourseTaken, AdditionalInfo, StateOfOrigin, LGA, NextOfKinName, NextOfKinStatus, NextOfKinPhone) ";
  $sql .= "VALUES (";
  $sql .= "'" . $staff['staff_number'] . "',";
  $sql .= "'" . $staff['F_Name'] . "',";
  $sql .= "'" . $staff['Email'] . "',";
  $sql .= "'" . $staff['PhoneNumber'] . "',";
  $sql .= "'" . $staff['Qualification'] . "',";
  $sql .= "'" . $staff['Gender'] . "',";
  $sql .= "'" . $staff['ContactAddress'] . "',";
  $sql .= "'" . $staff['DOB'] . "',";
  $sql .= "'" . $staff['DateEmployee'] . "',";
  $sql .= "'" . $staff['salary'] . "',";
  $sql .= "'" . $staff['CourseTaken'] . "',";
  $sql .= "'" . $staff['AdditionalInfo'] . "',";
  $sql .= "'" . $staff['StateOfOrigin'] . "',";
  $sql .= "'" . $staff['LGA'] . "',";
  $sql .= "'" . $staff['NextOfKinName'] . "',";
  $sql .= "'" . $staff['NextOfKinStatus'] . "',";
  $sql .= "'" . $staff['NextOfKinPhone'] . "'";
 // $sql .= "'" . $staff['NextOfKinAddress'] . "'";
  $sql .= ")";
  
 $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
  if($result) {
      return true;
    } else {
      // INSERT failed
	 // echo $sql;
     echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

}
 // Pages

  function find_all_staff() {
    global $db;

    $sql = "SELECT * FROM staff ";
    $sql .= "ORDER BY Qualification ASC, F_Name ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_staff_by_id($id) {
    global $db;

    $sql = "SELECT * FROM staff ";
    $sql .= "WHERE id='" . $id . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $staff = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $staff; // returns an assoc. array
  }

  /*function validate_page($page) {
    $errors = [];

    // subject_id
    if(is_blank($page['subject_id'])) {
      $errors[] = "Subject cannot be blank.";
    }

    // menu_name
    if(is_blank($page['menu_name'])) {
      $errors[] = "Name cannot be blank.";
    } elseif(!has_length($page['menu_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name must be between 2 and 255 characters.";
    }

    // position
    // Make sure we are working with an integer
    $postion_int = (int) $page['position'];
    if($postion_int <= 0) {
      $errors[] = "Position must be greater than zero.";
    }
    if($postion_int > 999) {
      $errors[] = "Position must be less than 999.";
    }

    // visible
    // Make sure we are working with a string
    $visible_str = (string) $page['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false.";
    }

    // content
    if(is_blank($page['content'])) {
      $errors[] = "Content cannot be blank.";
    }

    return $errors;
  }

  function insert_page($page) {
    global $db;

    /*$errors = validate_page($page);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "INSERT INTO pages ";
    $sql .= "(subject_id, menu_name, position, visible, content) ";
    $sql .= "VALUES (";
    $sql .= "'" . $page['subject_id'] . "',";
    $sql .= "'" . $page['menu_name'] . "',";
    $sql .= "'" . $page['position'] . "',";
    $sql .= "'" . $page['visible'] . "',";
    $sql .= "'" . $page['content'] . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
*/
  function update_staff($staff) {
    global $db;

    $errors = validate_staff($staff);
    if(!empty($errors)) {
      return $errors;
    }

    $sql = "UPDATE staff SET ";
    $sql .= "staff_number='" . $staff['staff_number'] . "', ";
    $sql .= "F_Name='" . $staff['F_Name'] . "', ";
	$sql .= "Email='" . $staff['Email'] . "', ";
	$sql .= "PhoneNumber='" . $staff['PhoneNumber'] . "', ";
	$sql .= "Qualification='" . $staff['Qualification'] . "', ";
    $sql .= "Gender='" . $staff['Gender'] . "', ";
    $sql .= "ContactAddress='" . $staff['ContactAddress'] . "', ";
	$sql .= "DOB='" . $staff['DOB'] . "', ";
    $sql .= "DateEmployee='" . $staff['DateEmployee'] . "' ";
	$sql .= "salary='" . $staff['salary'] . "', ";
	$sql .= "CourseTaken='" . $staff['CourseTaken'] . "', ";
	$sql .= "AdditionalInfo='" . $staff['AdditionalInfo'] . "', ";
	$sql .= "SET='" . $staff['StateOfOrigin'] . "', ";
	$sql .= "LGA='" . $staff['LGA'] . "', ";
	$sql .= "NextOfKinName='" . $staff['NextOfKinName'] . "', ";
	$sql .= "NextOfKinStatus='" . $staff['NextOfKinStatus'] . "', ";
	 $sql .= "NextOfKinPhone='" . $staff['NextOfKinPhone'] . "', ";
    $sql .= "WHERE id='" . $staff['id'] . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function detete_Application($id) {
    global $db;

    $sql = "DELETE FROM application ";
    $sql .= "WHERE id='" . $id . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }
  // Find all admins, ordered last_name, first_name
  function find_all_admins() {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "ORDER BY last_name ASC, first_name ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_admin_by_id($id) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function find_admin_by_username($username) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function validate_admin($admin, $options=[]) {

    $password_required = $options['password_required'] ?? true;

    if(is_blank($admin['first_name'])) {
      $errors[] = "First name cannot be blank.";
    } elseif (!has_length($admin['first_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "First name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['last_name'])) {
      $errors[] = "Last name cannot be blank.";
    } elseif (!has_length($admin['last_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "Last name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['email'])) {
      $errors[] = "Email cannot be blank.";
    } elseif (!has_length($admin['email'], array('max' => 255))) {
      $errors[] = "Last name must be less than 255 characters.";
    } elseif (!has_valid_email_format($admin['email'])) {
      $errors[] = "Email must be a valid format.";
    }

    if(is_blank($admin['username'])) {
      $errors[] = "Username cannot be blank.";
    } elseif (!has_length($admin['username'], array('min' => 8, 'max' => 255))) {
      $errors[] = "Username must be between 8 and 255 characters.";
    } elseif (!has_unique_username($admin['username'], $admin['id'] ?? 0)) {
      $errors[] = "Username not allowed. Try another.";
    }

    if($password_required) {
      if(is_blank($admin['password'])) {
        $errors[] = "Password cannot be blank.";
      } elseif (!has_length($admin['password'], array('min' => 12))) {
        $errors[] = "Password must contain 12 or more characters";
      } elseif (!preg_match('/[A-Z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 uppercase letter";
      } elseif (!preg_match('/[a-z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 lowercase letter";
      } elseif (!preg_match('/[0-9]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 number";
      } elseif (!preg_match('/[^A-Za-z0-9\s]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 symbol";
      }

      if(is_blank($admin['confirm_password'])) {
        $errors[] = "Confirm password cannot be blank.";
      } elseif ($admin['password'] !== $admin['confirm_password']) {
        $errors[] = "Password and confirm password must match.";
      }
    }
    
    return $errors;
  }

  function insert_admin($admin) {
    global $db;

    $errors = validate_admin($admin);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO admins ";
    $sql .= "(first_name, last_name, email, username, hashed_password) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $admin['first_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['last_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['email']) . "',";
    $sql .= "'" . db_escape($db, $admin['username']) . "',";
    $sql .= "'" . db_escape($db, $hashed_password) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);

    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_admin($admin) {
    global $db;

    $password_sent = !is_blank($admin['password']);

    $errors = validate_admin($admin, ['password_required' => $password_sent]);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "UPDATE admins SET ";
    $sql .= "first_name='" . db_escape($db, $admin['first_name']) . "', ";
    $sql .= "last_name='" . db_escape($db, $admin['last_name']) . "', ";
    $sql .= "email='" . db_escape($db, $admin['email']) . "', ";
    if($password_sent) {
      $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "', ";
    }
    $sql .= "username='" . db_escape($db, $admin['username']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function delete_admin($admin) {
    global $db;

    $sql = "DELETE FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1;";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

?>
