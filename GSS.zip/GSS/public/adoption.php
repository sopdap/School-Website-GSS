

<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include(SHARED_PATH . '/public_header.php'); ?>

<?php

/*

		if(is_post_request()) {
  $register_child = [];
  $register_child['child_surname'] = $_POST['child_surname'] ?? '';
  $register_child['other_name'] = $_POST['other_name'] ?? '';
  $register_child['maiden_name'] = $_POST['maiden_name'] ?? '';
  $register_child['child_gender'] = $_POST['child_gender'] ?? '';
  $register_child['dateOfBirth'] = $_POST['dateOfBirth'] ?? '';
  $register_child['stateOfOrigin'] = $_POST['stateOfOrigin'] ?? '';
  $register_child['localGovernment'] = $_POST['localGovernment'] ?? '';
  $register_child['AddmittedYear'] = $_POST['AddmittedYear'] ?? '';
  $register_child['childImage'] = $_POST['childImage'] ?? '';
  $register_child['NK_firstName'] = $_POST['NK_firstName'] ?? '';
  $register_child['NK_lastName'] = $_POST['NK_lastName'] ?? '';
  $register_child['NK_relationship'] = $_POST['NK_relationship'] ?? '';
  $register_child['NK_contactAddress'] = $_POST['NK_contactAddress'] ?? '';
  $register_child['NK_emailAddress'] = $_POST['NK_emailAddress'] ?? '';
  $register_child['NK_phoneNumber'] = $_POST['NK_phoneNumber'] ?? '';
  $register_child['NK_gender'] = $_POST['NK_gender'] ?? '';

  
    $result = insert_children($register_child);
  if($result === true) {
    $new_id = mysqli_insert_id($db);
    redirect_to(url_for('/admin/index.php?id=' . $new_id));
  } else {
    $errors = $result;
  }

} else {
	
	// display the blank form
	 $register_child = [];
  $register_child['child_surname'] = $_POST['child_surname'] ?? '';
  $register_child['other_name'] = $_POST['MiddleName'] ?? '';
  $register_child['maiden_name'] = $_POST['maiden_name'] ?? '';
  $register_child['child_gender'] = $_POST['child_gender'] ?? '';
  $register_child['dateOfBirth'] = $_POST['dateOfBirth'] ?? '';
  $register_child['stateOfOrigin'] = $_POST['stateOfOrigin'] ?? '';
  $register_child['localGovernment'] = $_POST['localGovernment'] ?? '';
  $register_child['AddmittedYear'] = $_POST['AddmittedYear'] ?? '';
  $register_child['childImage'] = $_POST['childImage'] ?? '';
  $register_child['NK_firstName'] = $_POST['NK_firstName'] ?? '';
  $register_child['NK_lastName'] = $_POST['NK_lastName'] ?? '';
  $register_child['NK_relationship'] = $_POST['NK_relationship'] ?? '';
  $register_child['NK_contactAddress'] = $_POST['NK_contactAddress'] ?? '';
  $register_child['NK_emailAddress'] = $_POST['NK_emailAddress'] ?? '';
  $register_child['NK_phoneNumber'] = $_POST['NK_phoneNumber'] ?? '';
  $register_child['NK_gender'] = $_POST['NK_gender'] ?? '';
  
  
  // Old Code the blank form
 /// $subject = [];
  //$subject["menu_name"] = '';
 // $subject["position"] = $subject_count;
 // $subject["visible"] = '';
}

//$student_set = find_all_student();
//$subject_count = mysqli_num_rows($student_set) + 1;
//mysqli_free_result($student_set);
*/
?>




	<div class="clearfix"></div>
	</div>
	<!-- banner -->
	<div class="banner-inner-page">

	</div>
	<!--//banner -->
	<!--/single-->
	<div class="container">

  
  <br>          
   
   <div class="row">
  <div class="col-sm-6">
<h2 align="center">Procedure for Adoption</h2>
<br>
<p> <span class="warning"> Please Read the following Carefully.</span></p> 
<form class="form-inline" action="adopt_processing.php" method="post"> <br>
	  
	  <h4>As a mission organization under Evangelical church winning All (ECWA) with a mission of reaching out to the unreached and the needy.</h4> <br>

	  <h5>Please come along with the following document for the adoption process </h5> <br>

	  	<li>To Adopt a child, you have to notify the police and the police will issue a police report as the federal government arm who are charged with the responsibility of life of the nation. </li><br>

	  	<li>Bring a report from the state ministry of women affairs under the director of child development at the state level, the social welfare at the local government level.</li> <br>
	  	<li>Also come along with medical report from the apporve state or federal government hospital</li>


	 
	  
</div>
  <div class="col-sm-6">
  
  <h2 align="center">Application Form</h2>

	  <label for="FirstName" class="mr-sm-2">First Name:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="FirstName" name="FirstName" required="" value="<?php //echo $register_child['NK_firstName']; ?>">

	  <label for="LastName" class="mr-sm-2">Last Name:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="LastName" name="LastName" required="" value="<?php //echo $register_child['NK_lastName']; ?>">


	  <label for="contactAddress" class="mr-sm-2">Contact Address:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="contactAddress" name="contactAddress" required="" value="<?php //echo $register_child['NK_contactAddress']; ?>">

	   <label for="contactEmail" class="mr-sm-2">Email Address:</label>
	  <input type="email" class="form-control mb-2 mr-sm-2" id="contactEmail" name="contactEmail" required="" value="<?php //echo $register_child['NK_emailAddress']; ?>">

	  <label for="phoneNumber" class="mr-sm-2">Phone Number:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="phoneNumber" name="phoneNumber" value="<?php //echo $register_child['NK_phoneNumber']; ?>">

		 <label for="gender" class="mr-sm-2">Sex:</label>
		  <select name="sex" class="form-control">
			    <option selected>Select Gender</option>
			    <option value="Male">Male</option>
			    <option value="Female">Female</option>
			   
	  	</select>

	<br>
		<h4 align="center"> Next of Kin Details</h4>
		<hr>
	  <br />
	  	  <label for="nextOfKin" class="mr-sm-2">Next of Kin Name:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="nextOfKin" name="nextOfKin" required="" value="<?php //echo $register_child['NK_relationship']; ?>">
	  <br>
	  	  <label for="NK_phoneNumber" class="mr-sm-2">Next of Kin Phone Number:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="NK_phoneNumber" name="NK_phoneNumber" required="" value="<?php //echo $register_child['NK_relationship']; ?>">
	  <br>
	   <label for="NK_Contact_Address" class="mr-sm-2">Contact of Next Kin:</label>
	  <input type="text" class="form-control mb-2 mr-sm-2" id="NK_Contact_Address" name="NK_Contact_Address" required="" value="<?php //echo $register_child['NK_relationship']; ?>">
	  <br>
	  <label for="gender" class="mr-sm-2">Type of Child Needed:</label>
		  <select name="typeOfChild" class="form-control">
			    <option selected>Select Child Type</option>
			    <option value="Male">Male</option>
			    <option value="Female">Female</option>
			   
	  	</select>
	  	<br>

	  	<label for="nextOfKin" class="mr-sm-2">Reason for Adoption:</label>

	  <input type="textarea" class="form-control mb-2 mr-sm-2" id="nextOfKin" name="reason" required="" value="<?php //echo $register_child['NK_relationship']; ?>">
	  	<br>




	  <button type="submit" class="btn btn-primary mb-2">Apply for Child</button>

 </form>
	</form>
	</div> 
   



<?php include(SHARED_PATH . '/admin_page_footer.php'); ?>