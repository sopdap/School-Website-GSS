
<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include(SHARED_PATH . '/public_header.php'); ?>

<div class="clearfix"></div>
	</div>
	<!-- banner -->
	<div class="banner-inner-page">

	</div>
	<!--//banner -->
	<!--/single-->
	<div class="container">
 <br>

  <h2 align="center">APPLICATION DETAILS</h2>
  <hr>
  <hr> 

<?php
// $id = isset($_GET['id']) ? $_GET['id'] : '1';
$id = $_GET['id'] ?? '1'; // PHP > 7.0

$application = find_application_by_id($id);

?>
<div class="container">

   <div class="row">
  <div class="col-sm-6">
 

    <h1 align="center">NAME: <?php echo h($application['firstName']); ?>  <?php echo h($application['lastName']); ?> </h1> 
    
    
    <?php echo "<br />";?>
    <p><b> Contact Address: </b> <?php echo h($application['contactAddress']); ?></p>
    
    <?php echo "<br />";?>
    <p><b> Applicatant Phone Number: </b> <?php echo h($application['phoneNumber']); ?></p>

   <?php echo "<br />";?>
    
    <p><b>Sex:: </b> <?php echo h($application['sex']); ?> , <b>Next of Kin Name: </b> <?php echo h($application['nextOfKin']); ?></p>
    <?php echo "<br />";?>
    <p><b> Next of Kin Details: </b> <?php echo h($application['NK_PhoneNumber']); ?></p>

   			
  </div>
  
  <div class="col-sm-6">
<h2> Next of Kin Detals </h2>
   






</div>
</div>
    <br />
        <p align="center"> <button class="btn-primary" onClick="window.print()" >Print</button> </p>
     <?php echo "<br />";?>
 <p align="right"> <a  href="<?php echo url_for(('applicationPrint.php')); ?>">&laquo; Back to Feedback List</a> </p>

<?php include(SHARED_PATH . '/admin_page_footer.php'); ?>