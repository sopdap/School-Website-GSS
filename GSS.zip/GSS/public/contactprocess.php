<?php 
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "childcareinformationsystem";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbName);

$contactName = $_POST['contactName'];
$contact_email = $_POST['contact_email'];
$contact_phone = $_POST['contact_phone'];
$contact_subject = $_POST['contact_subject'];
$message = $_POST['message'];

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO contact ( contactName, contact_email, contact_phone, contact_subject, message)
VALUES ('$contactName', '$contact_email', '$contact_phone', '$contact_subject' , '$message')";

if (mysqli_query($conn, $sql)) {   	

    echo  "<h1> Thanks for getting in touch with us. We will get back to you as soon as possible!</h1>";
    echo "<a href='index.php' > Please click here to go back home </a>";
   
    echo //"<script>window.location= 'index.php';</script>";

    die;
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>