<?php  require_once ('../private/initialize.php'); ?>

<?php 
//error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "childcareinformationsystem";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbName);

$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$contactAddress = $_POST['contactAddress'];
$phoneNumber = $_POST['phoneNumber'];
$contactEmail = $_POST['contactEmail'];
$sex = $_POST['sex'];
//$image = $_POST['image'];
$nextOfKin = $_POST['nextOfKin'];
$NK_phoneNumber = $_POST['NK_phoneNumber'];
$NK_Contact_Address = $_POST['NK_Contact_Address'];
$typeOfChild = $_POST['typeOfChild'];
$reason = $_POST['reason'];

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO application (FirstName, LastName, contactAddress, phoneNumber, contactEmail, sex, nextOfKin, NK_phoneNumber, NK_Contact_Address, typeOfChild, reason)
VALUES ('$FirstName', '$LastName', '$contactAddress', '$phoneNumber', '$contactEmail', '$sex', '$nextOfKin', '$NK_phoneNumber', '$NK_Contact_Address', '$typeOfChild', '$reason')";

if (mysqli_query($conn, $sql)) {   	


  	//echo ('applicationdetails.php?id=' . h(u($application['application_id']))); 

    echo "Application sumbitted successfullly";
    echo"<a href ='index.php'>Click Here to Go back Home</a>";
   ///Redirect_to(url_for('/applicationdetails.php?id=' . $new_id)); die; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>
