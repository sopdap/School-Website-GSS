<?php
session_start();

if (!isset($_SESSION['admin'])) {
  echo "<script>window.location= 'login.php';</script>";
}

?>

<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include(SHARED_PATH . '/public_header.php'); ?>

	<div class="clearfix"></div>
	</div>
	<!-- banner -->
	<div class="banner-inner-page">

	</div>
	<!--//banner -->
	<!--/single-->
	<div class="container">
 <br>

  <h2>APPLICATION TABLE</h2>
  <p>List of Applicants</p> 
 <?php  $application_set = find_all_application(); ?>          
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>contactPhoneNumber</th>
        <th>Action</th>

      </tr>
    </thead>
<?php while($application = mysqli_fetch_assoc($application_set)) { ?>
    <tbody>
      <tr>
        <td><?php echo h($application['firstName']); ?></td>
        <td><?php echo h($application['lastName']); ?></td>
        <td><?php echo h($application['phoneNumber']); ?></td>
        <td><?php echo h($application['contactEmail']); ?></td>
        
        <td><a class="action" href="<?php echo ('applicationdetails.php?id=' . h(u($application['application_id']))); ?>"><button type="button" class="btn-success">View Details</button> </a></td>
      </tr>

      
   <?php } ?>
    </tbody>
  </table>
  
  <div class="container">
  	<div class=" row"> 
  		<div class="col-sm-12"> 
  			<h2 align="center"> <a href="#">Print All</a></h2>

  		</div>

  </div>
</div>
	<!-- footer -->
	<?php include(SHARED_PATH . '/admin_page_footer.php'); ?>