<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include(SHARED_PATH . '/main_header.php'); ?>
<!--//header-->

	<div class="banner_bottom" id="about">
		<div class="container">
			<h3 class="tittle_w3_agileinfo">About Our Relief</h3>
			<div class="inner_sec_info_w3layouts">
				<div class="help_full">
					<ul class="rslides" id="slider4">
						<li>
							<div class="respon_info_img">
								<img src="../assets/images/banner3.jpg" class="img-responsive" alt="Relief">
							</div>
							<div class="banner_bottom_left">
								<h4>Feed For Hungry Child</h4>

								<p>The wife who was also a missionary, usually go out for shopping in terminal Market in Jos and almagiri children, street children usually come around her and solicit for arm looking at her as a Westerner as they usually call her Baturiya Mai Taimako. She usually buys them some fruits and also money whenever they come around her. Gradually, she started cooking food from her home and brings to these needy children because of her passion, sympathy, love, and kindness to children who needed someone to help them and also use the medium to evangelise to them. </p>
								<div class="ab_button">
									<a class="btn btn-primary btn-lg hvr-underline-from-left" href="#" role="button"> </a>
								</div>
							</div>
						</li>
						<li>
							<div class="respon_info_img">
								<img src="../assets/images/banner2.jpg" class="img-responsive" alt="Relief">
							</div>
							<div class="banner_bottom_left">
								<h4>Education to Every Child</h4>

								<p>These heart of generosity continues today in which brought about many other branches of this passionate organization in various States of the Federation after being registered and pass through all due process laid down by the Federal State and local Government, Charter Art, Charter Protection Art, and other document as the nation provide with the child safety as the priority to give them hope for the future.</p>

								<div class="ab_button">
									<a class="btn btn-primary btn-lg hvr-underline-from-left" href="#" role="button"> </a>
								</div>
							</div>
						</li>
						<li>
							<div class="respon_info_img">
								<img src="../assets/images/banner1.jpg" class="img-responsive" alt="Relief">
							</div>
							<div class="banner_bottom_left">
								<h4>Patient and Family Support</h4>
								These heart of generosity continues today in which brought about many other branches of this passionate organization in various States of the Federation after being registered and pass through all due process laid down by the Federal State and local Government, Charter Art, Charter Protection Art, and other document as the nation provide with the child safety as the priority to give them hope for the future.</p>
								<div class="ab_button">
									<a class="btn btn-primary btn-lg hvr-underline-from-left" href="#" role="button"> </a>
								</div>
							</div>
						</li>
						<li>
							<div class="respon_info_img">
								<img src="../assets/images/banner4.jpg" class="img-responsive" alt="Relief">
							</div>
							<div class="banner_bottom_left">
								<h4>Provide Treatment</h4>
								These heart of generosity continues today in which brought about many other branches of this passionate organization in various States of the Federation after being registered and pass through all due process laid down by the Federal State and local Government, Charter Art, Charter Protection Art, and other document as the nation provide with the child safety as the priority to give them hope for the future.</p>
								<div class="ab_button">
									<a class="btn btn-primary btn-lg hvr-underline-from-left" href="#l" role="button"> </a>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<div class="news-main">
				<div class="col-md-6 banner_bottom_left">
					<div class="banner_bottom_pos">
						<div class="banner_bottom_pos_grid">
							<div class="col-xs-3 banner_bottom_grid_left">
								<div class="banner_bottom_grid_left_grid">
									<div class="dodecagon b1">
										<div class="dodecagon-in b1">
											<div class="dodecagon-bg b1">
												<span class="fas fa-camera-retro" aria-hidden="true"></span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-9 banner_bottom_grid_right">
								<h4>Health and Medication</h4>
								<p>Support us, to fight common dieases around us such as Malaria, Tifold, Cold and Kata, etc.</p>
								<div class="barWrapper">
									<span class="progressText">
										<b>Donators</b>
									</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
											<span class="popOver" data-toggle="tooltip" data-placement="top" title="85%"> </span>
										</div>
									</div>
								</div>
							</div>


							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="col-md-6 banner_bottom_left">
					<div class="banner_bottom_pos">
						<div class="banner_bottom_pos_grid">
							<div class="col-xs-3 banner_bottom_grid_left">
								<div class="banner_bottom_grid_left_grid">
									<div class="dodecagon b1">
										<div class="dodecagon-in b1">
											<div class="dodecagon-bg b1">
												<span class="far fa-thumbs-up" aria-hidden="true"></span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-9 banner_bottom_grid_right">
								<h4>Wildlife and Ecosystems</h4>
								<p>We beleive in Natural, Support our on going play ground garden for children</p>
								<div class="barWrapper">
									<span class="progressText">
										<b>Donators</b>
									</span>
									<div class="progress">
										<div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
											<span class="popOver" data-toggle="tooltip" data-placement="top" title="75%"> </span>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--//ab-->
	<!--/what-->
	<div class="works" id="services">
		<div class="container">
			<h3 class="tittle_w3_agileinfo cen">Why Choose Us</h3>
			<div class="inner_sec_info_w3layouts">
				<div class="ser-first">
					<div class="col-md-3 ser-first-grid text-center">
						<div class="dodecagon">
							<div class="dodecagon-in">
								<div class="dodecagon-bg">
									<span class="far fa-edit" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<h3>Food Delivering</h3>
						<p>We provide for the Alumagiri and Homeless children since 2000.</p>
					</div>
					<div class="col-md-3 ser-first-grid text-center">
						<div class="dodecagon">
							<div class="dodecagon-in">
								<div class="dodecagon-bg">
									<span class="far fa-paper-plane" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<h3>Volunteer</h3>
						<p>Join our Volunteer program to promote education, and awarness to less priviledges.</p>
					</div>
					<div class="col-md-3 ser-first-grid text-center">
						<div class="dodecagon">
							<div class="dodecagon-in">
								<div class="dodecagon-bg">
									<span class="far fa-star" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<h3>Donation</h3>
						<p>You can support, Let do it together and change the life of our future leaders.</p>
					</div>
					<div class="col-md-3 ser-first-grid text-center">
						<div class="dodecagon">
							<div class="dodecagon-in">
								<div class="dodecagon-bg">
									<span class="far fa-user" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<h3>Adoption</h3>
						<p>We need your help to sponsor fatherless children; your little contribution matter to us</p>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>

		</div>
	</div>
	<!--//what-->
	
	<!--/gallery-->
	<div class="banner_bottom proj" id="gallery">
		<div class="wrap_view">
			<h3 class="tittle_w3_agileinfo">Gallery</h3>
			<div class="inner_sec_info_w3layouts">
				<ul class="portfolio-categ filter">
					<li class="port-filter all active">
						<a href="#">All</a>
					</li>
					<li class="cat-item-1">
						<a href="#" title="Category 1">Charity</a>
					</li>
					<li class="cat-item-2">
						<a href="#" title="Category 2">Nature</a>
					</li>
					<li class="cat-item-3">
						<a href="#" title="Category 3">Wildlife</a>
					</li>
					<li class="cat-item-4">
						<a href="#" title="Category 4">Children</a>
					</li>
				</ul>


				<ul class="portfolio-area">

					<li class="portfolio-item2" data-id="id-0" data-type="cat-item-4">
						<div>
							<span class="image-block img-hover">
								<a class="image-zoom" href="images/g1.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g1.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-1" data-type="cat-item-2">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g2.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g2.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-2" data-type="cat-item-1">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g3.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g3.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-3" data-type="cat-item-4">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g4.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g4.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-4" data-type="cat-item-3">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g5.jpg">

									<img src="../assets/images/g5.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-5" data-type="cat-item-2">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g6.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g6.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-6" data-type="cat-item-1">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g7.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g7.jpg" class="img-responsive" alt="Relief">

								</a>
							</span>
						</div>
					</li>


					<li class="portfolio-item2" data-id="id-7" data-type="cat-item-1">
						<div>
							<span class="image-block">
								<a class="image-zoom" href="images/g8.jpg" rel="prettyPhoto[gallery]">

									<img src="../assets/images/g8.jpg" class="img-responsive" alt="Relief">


								</a>
							</span>
						</div>
					</li>

					<div class="clearfix"> </div>
				</ul>
				<!--end portfolio-area -->
			</div>
		</div>
	</div>


	<!--//gallery-->
	<div class="events-coming">
		<h3 class="tittle_w3_agileinfo cen"> Our Events Coming Soon
		</h3>
		<div class="inner_sec_info_w3layouts">
			<div class="content">
				<div class="simply-countdown-custom" id="simply-countdown-custom"></div>
			</div>
		</div>
	</div>
	<!--/last-->
	
	<!--//price-->
	<!-- Modal1 -->
	<div class="modal fade" id="myModal1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header book-form">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4>Sign up Form</h4>
					<form action="#" method="post">
						<input type="text" name="Name" placeholder="Your Name" required="" />
						<input type="email" name="Email" class="email" placeholder="Email" required="" />
						<input type="password" name="Password" class="password" placeholder="Password" required="" />
						<div class="check-box">
							<input name="chekbox" type="checkbox" id="brand" value="">
							<label for="brand">
								<span></span>Remember Me.</label>
						</div>
						<input type="submit" value="Sign Up">
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal1 -->
	<!--/testimonials-->
	<div class="tesimonials" id="test">
		<div class="container">
			<h3 class="tittle_w3_agileinfo cen">Testimonials</h3>
			<div class="inner_sec">
				<div class="test_grid_sec">
					<div class="col-md-offset-2 col-md-8">
						<div class="carousel slide two" data-ride="carousel" id="quote-carousel">
							<!-- Bottom Carousel Indicators -->
							<ol class="carousel-indicators two">
								<li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
								<li data-target="#quote-carousel" data-slide-to="1"></li>
								<li data-target="#quote-carousel" data-slide-to="2"></li>
							</ol>

							<!-- Carousel Slides / Quotes -->
							<div class="carousel-inner">

								<!-- Quote 1 -->
								<div class="item active">
									<blockquote>
										<div class="test_grid">
											<div class="col-sm-3 text-center test_img">
												<div class="dodecagon c1">
													<div class="dodecagon-in c1">
														<div class="dodecagon-bg c1">

														</div>
													</div>
												</div>
											</div>
											<div class="col-sm-9 test_img_info">
												<p>
													<i class="fas fa-quote-left"></i> The Child I adopted is doing fine, you people are doing great.
													</p>
												<h6>Abdulaih Maikasuwa</h6>
											</div>
										</div>
									</blockquote>
								</div>
								<!-- Quote 2 -->
								<div class="item">
									<blockquote>
										<div class="test_grid">
											<div class="col-sm-3 text-center test_img">
												<div class="dodecagon c2">
													<div class="dodecagon-in c2">
														<div class="dodecagon-bg c2">

														</div>
													</div>
												</div>
											</div>
											<div class="col-sm-9 test_img_info">
												<p>
													<i class="fas fa-quote-left"></i>I must commend the efforts of this organization in helping these children. Before adoption, they were well taken care of and after adoption, they are well mannered which shows that they were trained well by the organization</p>
												<h6>Oseh Oremeyi Blessing</h6>
											</div>
										</div>
									</blockquote>
								</div>
								<!-- Quote 3 -->
								<div class="item">
									<blockquote>
										<div class="test_grid">
											<div class="col-sm-3 text-center test_img">
												<div class="dodecagon c3">
													<div class="dodecagon-in c3">
														<div class="dodecagon-bg c3">

														</div>
													</div>
												</div>
											</div>
											<div class="col-sm-9 test_img_info">
												<p>
													<i class="fas fa-quote-left"></i> Maecenas quis neque libero. Class aptent taciti.Lorem ipsum dolor sit amet, consectetur adipiscing elit.
													Etiam auctor nec lacus ut tempor. Mauris.</p>
												<h6>Alice Williams</h6>
											</div>
										</div>
									</blockquote>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--//testimonials-->

	<!-- /newsletter-->
	
	<!-- footer -->
	<div class="footer" id="contact">
		<div class="footer_inner_info_wthree_agileits">
			<!--/tabs-->
			<div class="responsive_tabs">
				<div id="horizontalTab">
					<ul class="resp-tabs-list">
						<li>Contact Info</li>
						<li>Send Message</li>
						<li>View Map</li>
					</ul>
					<div class="resp-tabs-container">
						<!--/tab_one-->
						<div class="tab1">
							<div class="tab-info">

								<div class="address">
									<div class="col-md-4 address-grid">
										<div class="address-left">
											<div class="dodecagon f1">
												<div class="dodecagon-in f1">
													<div class="dodecagon-bg f1">
														<span class="fas fa-phone-volume" aria-hidden="true"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="address-right">
											<h6>Phone Number</h6>
											<p>+2348160413494,+234812345678</p>

										</div>
										<div class="clearfix"> </div>
									</div>
									<div class="col-md-4 address-grid">
										<div class="address-left">
											<div class="dodecagon f1">
												<div class="dodecagon-in f1">
													<div class="dodecagon-bg f1">
														<span class="far fa-envelope" aria-hidden="true"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="address-right">
											<h6>Email Address</h6>
											<p>Email :
												<a href="mailto:support@ccis.com"> support@ccis.com</a>
											</p>
										</div>
										<div class="clearfix"> </div>
									</div>
									<div class="col-md-4 address-grid">
										<div class="address-left">
											<div class="dodecagon f1">
												<div class="dodecagon-in f1">
													<div class="dodecagon-bg f1">
														<span class="fas fa-map-marker-alt" aria-hidden="true"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="address-right">
											<h6>Location</h6>
											<p>Bukan-Sidi, Lafia,Nasarawa State, Nigeria.

											</p>
										</div>
										<div class="clearfix"> </div>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
						</div>
						<!--//tab_one-->
						<div class="tab2">

							<div class="tab-info">
								<div class="contact_grid_right">
									<h6>Please fill this form to contact with us.</h6>
									<form action="contactprocess.php" method="post">
										<div class="contact_left_grid">
											<input type="text" name="contactName" placeholder="Name" required="">
											<input type="email" name="contact_email" placeholder="Email" required="">

											<input type="text" name="contact_phone" placeholder="Telephone" required="">
											<input type="text" name="contact_subject" placeholder="Subject" required="">
											<textarea name="message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message...';}" required="">Message...</textarea>
											<input type="submit" value="Submit">
											<input type="reset" value="Clear">
											<div class="clearfix"> </div>
										</div>
									</form>
								</div>
							</div>
						</div>
						<!--//tab_two-->
						<div class="tab3">

							<div class="tab-info">
								<div class="contact-map">

									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d100949.24429313939!2d-122.44206553967531!3d37.75102885910819!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2sSan+Francisco%2C+CA%2C+USA!5e0!3m2!1sen!2sin!4v1472190196783"
									    class="map" style="border:0" allowfullscreen=""></iframe>
								</div>

							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
			<!--//tabs-->
			<div class="clearfix"> </div>
			<ul class="social-nav model-3d-0 footer-social social two">
				<li>
					<a href="#" class="facebook">
						<div class="front">
							<i class="fab fa-facebook-f" aria-hidden="true"></i>
						</div>

					</a>
				</li>
				<li>
					<a href="#" class="twitter">
						<div class="front">
							<i class="fab fa-twitter" aria-hidden="true"></i>
						</div>

					</a>
				</li>
				<li>
					<a href="#" class="instagram">
						<div class="front">
							<i class="fab fa-instagram" aria-hidden="true"></i>
						</div>

					</a>
				</li>
				<li>
					<a href="#" class="pinterest">
						<div class="front">
							<i class="fab fa-linkedin" aria-hidden="true"></i>
						</div>

					</a>
				</li>
			</ul>
			<p class="copy-right"> <?php echo date('Y'); ?> © Child Care Information System. All rights reserved | Design by
				<a href="http://sopdap.com.ng/">HND OLUBUKOLA</a>
			</p>
		</div>
	</div>
	<!-- //footer -->
	<script type="text/javascript" src="../assets/js/jquery-2.2.3.min.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap.js"></script>
	<!-- script for responsive tabs -->
	<script src="../assets/js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true, // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function (event) { // Callback function if tab is switched
					var $tab = $(this);
					var $info = $('#tabInfo');
					var $name = $('span', $info);
					$name.text($tab.text());
					$info.show();
				}
			});
			$('#verticalTab').easyResponsiveTabs({
				type: 'vertical',
				width: 'auto',
				fit: true
			});
		});
	</script>
	<!--// script for responsive tabs -->
	<script src="../assets/js/responsiveslides.min.js"></script>
	<script>
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 4
			$("#slider4").responsiveSlides({
				auto: true,
				pager: true,
				nav: false,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});

		});
	</script>
	<script type="text/javascript" src="../assets/js/all.js"></script>
	<script>
		$('ul.dropdown-menu li').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
		});
	</script>

	<!-- js -->
	<script type="text/javascript" src="../assets/js/simplyCountdown.js"></script>
	<link href="../assets/css/simplyCountdown.css" rel='stylesheet' type='text/css' />
	<script>
		var d = new Date();
		simplyCountdown('simply-countdown', {
			year: d.getFullYear(),
			month: d.getMonth() + 2,
			day: 25
		});
		simplyCountdown('simply-countdown-custom', {
			year: d.getFullYear(),
			month: d.getMonth() + 2,
			day: 25
		});
		$('#simply-countdown-losange').simplyCountdown({
			year: d.getFullYear(),
			month: d.getMonth() + 2,
			day: 25
		});
	</script>
	<!--js-->
	<!--/tooltip -->
	<script>
		$(function () {
			$('[data-toggle="tooltip"]').tooltip({
				trigger: 'manual'
			}).tooltip('show');
		});

		// $( window ).scroll(function() {   
		// if($( window ).scrollTop() > 10){  // scroll down abit and get the action   
		$(".progress-bar").each(function () {
			each_bar_width = $(this).attr('aria-valuenow');
			$(this).width(each_bar_width + '%');
		});

		//  }  
		// });
	</script>
	<!--//tooltip -->
	<!-- Smooth-Scrolling-JavaScript -->
	<script type="text/javascript" src="../assets/js/easing.js"></script>
	<script type="text/javascript" src="../assets/js/move-top.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll, .navbar li a, .footer li a").click(function (event) {
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //Smooth-Scrolling-JavaScript -->
	<script type="text/javascript">
		$(document).ready(function () {
			/*
									var defaults = {
							  			containerID: 'toTop', // fading element id
										containerHoverID: 'toTopHover', // fading element hover id
										scrollSpeed: 1200,
										easingType: 'linear' 
							 		};
									*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>


	<a href="#home" class="scroll" id="toTop" style="display: block;">
		<span id="toTopHover" style="opacity: 1;"> </span>
	</a>

	<!-- jQuery-Photo-filter-lightbox-Gallery-plugin -->
	<script type="text/javascript" src="../assets/js/jquery-1.7.2.js"></script>
	<script src="../assets/js/jquery.quicksand.js" type="text/javascript"></script>
	<script src="../assets/js/script.js" type="text/javascript"></script>
	<script src="../assets/js/jquery.prettyPhoto.js" type="text/javascript"></script>
	<!-- //jQuery-Photo-filter-lightbox-Gallery-plugin -->


</body>

</html>