<?php
	$page_title = 'Our News || Registry'
;?>
<?php include("private/initialize.php"); ?>
<?php  include("private/header.php"); ?>

<?php
// $id = isset($_GET['id']) ? $_GET['id'] : '1';
$id = $_GET['id'] ?? '1'; // PHP > 7.0

$news = find_news_by_id($id);

?>

<?php $page_title = 'Show Page'; ?>
<div id="content">

  
  <div class="page show">

    <h1>Heading: <?php echo h($news['title']); ?> </h1> 
    <?php echo "<br />";?>
    <p><?php echo h($news['content']); ?></p>

  <a class="back-link" href="<?php echo ('/Registry/news.php'); ?>">&laquo; Back to News List</a>
  </div>

</div>

<?php include('private/footer.php'); ?>
