<?php  require_once ('../../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Delete:Result';

?>
<?php include(SHARED_PATH . '/admin_header.php'); ?>

<div class="container">
 <br>

  <h2 align="center">Contact Details</h2>
  <hr>
  <hr> 

  <?php

if(!isset($_GET['id'])) {
  redirect_to('dashboard.php');
}
$id = $_GET['id'];

if(is_post_request()) {

  $result = delete_children($id);
  
  redirect_to('dashboard.php');

} else {
  $register_child = find_children_by_id($id);
}

?>

<?php $page_title = 'Delete Children Details'; ?>
 <div class="login-right">
<div class="container">
    <div class=" row"> 
      <div class="col-sm-12"> 

  

  <div class="content">
    <h2 align="center">Delete Children</h2>
    <p><span>Are you sure you want to delete this Children Details?</span></p>
    <p class="item"><?php echo h($register_child['child_surname']); ?></p>
    

    <form action="<?php echo ('delete.php?id=' . h(u($register_child['child_id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Children" />
      </div>
    </form>
  </div>

</div>
<p><a class="back-link" href="<?php echo('dashboard.php'); ?>">&laquo; Back to List</a></p>

<?php ///include(SHARED_PATH . '/staff_footer.php'); ?>
