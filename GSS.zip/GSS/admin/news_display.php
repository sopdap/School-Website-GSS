<?php
session_start();

if (!isset($_SESSION['admin'])) {
  echo "<script>window.location= 'login.php';</script>";
}

?>
<?php  require_once ('../private/initialize.php'); ?>
<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Dashboard';

?>
<?php include( '../shared/admin_header.php'); ?>
    <header id="head" class="secondary">
                <div class="container">
                        <h1>Notice Board </h1>
                        <p> Welcome Back Admin</p>
                    </div>
        </header>
<div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="banner-inner-page">

  </div>
  <!--//banner -->
  <!--/single-->
  <div class="container">
 <br>

  <h2>Notification Board</h2>
  <p>List update News </p> 
 <?php $news_set = find_all_news(); ?>   
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Author</th>
        <th>Heading</th>
        <th>Message</th>
        <th>Posted Time</th>
         <th>Action</th>

      </tr>
      <?php while($news = mysqli_fetch_assoc($news_set)) { ?>
    </thead>

      <tr>
          <td><?php echo h($news['authorName']); ?></td>
          <td><?php echo h($news['heading']); ?></td>
           <td><?php echo h($news['message']); ?></td>
          <td><?php echo h($news['postTime']); ?></td>
          <td><a class="action" href="<?php echo ('news_show.php?id=' . h(u($news['new_id']))); ?>">Read More</a></td>
          </td>
    	  </tr>
      <?php } ?>
  	</table>

    <?php
      mysqli_free_result($news_set);
    ?>
  </div>

</div>

<?php  include("../shared/footer.php"); ?>