<?php include('../shared/admin_header.php'); ?>
<?php 

//error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "gssdb";
// Create connection
$output ="";
if(isset($_POST['submit'])){
$conn = new mysqli($servername, $username, $password, $dbName);

$authorName = $_POST['authorName'];
$heading = $_POST['heading'];
$message = $_POST['message'];


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO new (authorName, heading, message)
VALUES ('$authorName', '$heading', '$message')";

if (mysqli_query($conn, $sql)) {   	


  	//echo ('applicationdetails.php?id=' . h(u($application['application_id']))); 

    $output = "Your Notic Update successfullly" . "<a href ='index.php'>Click Here to Go back Home</a>";
   ///Redirect_to(url_for('/applicationdetails.php?id=' . $new_id)); die; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}

?>

		<header id="head" class="secondary">
            <div class="container">
                    <h1>Notification Board</h1>
                    <p>Information is the key!</p>
                </div>
    </header>


	<!-- container -->
	<div class="container">
				<div class="row">
					<div class="col-md-8">
						<h3 class="section-title">Your Message</h3>
						
						<h3 class="section-title"><span style="color: green"><?php echo $output; ?></span></h3>
						<form class="form-light mt-20" role="form" action="postNews.php" method="post">
							<div class="form-group">
								<label>Author</label>
								<input type="text" class="form-control" placeholder="Author Name" name="authorName">
							</div>
							<div class="form-group">
								<label>Heading</label>
								<input type="text" class="form-control" placeholder="News Heading" name="heading">
							</div>
							<div class="form-group">
								<label>Message</label>
								<textarea class="form-control" id="message" placeholder="Write you message here..." style="height:100px;" name="message"></textarea>
							</div>
							<button type="submit" class="btn btn-two" name="submit">Post Update</button><p><br/></p>
						</form>
					</div>
					<div class="col-md-4">
						<div class="row">
							<div class="col-md-6">
								

								</div>
							</div> 
						</div> 						
					</div>
				</div>
			</div>
	<!-- /container -->

	   <?php include('../shared/footer.php'); ?>


	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>

	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	<script src="assets/js/google-map.js"></script>


</body>
</html>
