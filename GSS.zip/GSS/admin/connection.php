<?php
	//instatntiating connection
	$db_hostname = 'localhost';
	 $db_username = 'root';
	 $db_database = 'gssdb';
	 $db_password = '';
	 $db = new mysqli("$db_hostname","$db_username","$db_password","$db_database");