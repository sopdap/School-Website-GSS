<?php
session_start();

if (!isset($_SESSION['admin'])) {
  echo "<script>window.location= 'login.php';</script>";
}

?>

<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include( '../shared/admin_header.php'); ?>
<header id="head" class="secondary">
                <div class="container">
                        <h1>Admin Dashboard </h1>
                        <p> Welcome Back Admin</p>
                    </div>
        </header>

  <div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="banner-inner-page">

  </div>
  <!--//banner -->
  <!--/single-->
  <div class="container">
 <br>

  <h2>FEEDBACK TABLE</h2>
  <p>Information Received from Contact form </p>   

<?php  $contact_set = find_all_contact(); ?>           
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Email Address</th>
        <th>Phone Number</th>
        <th>Subject</th>  
        <th>Message.</th>
        <th>Action</th>

      </tr>
    </thead>
<?php while($contact = mysqli_fetch_assoc($contact_set)) { ?>
    <tbody>
      <tr>
        <td><?php echo h($contact['senderName']); ?></td>
        <td><?php echo h($contact['emailAddress']); ?></td>
        <td><?php echo h($contact['contactPhoneNumber']); ?></td>
        <td><?php echo h($contact['subject']); ?></td>
        
        <td><?php echo h($contact['message']); ?></td>
        <td><a class="action" href="<?php echo ('contact_details.php?id=' . h(u($contact['contact_id']))); ?>"><button class="btn-success">View Details</button></a></td>
      </tr>

  
    
    </tbody>
 <?php } ?>
  </table>
  
	<!-- footer -->
	<?php include('../shared/footer.php'); ?>