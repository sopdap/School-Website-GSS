<?php
session_start();

if (!isset($_SESSION['admin'])) {
  echo "<script>window.location= 'login.php';</script>";
}

?>

<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include( '../shared/admin_header.php'); ?>
<header id="head" class="secondary">
                <div class="container">
                        <h1>Contact Form Details  </h1>
                        <p> The Feedback</p>
                    </div>
        </header>

  <div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="banner-inner-page">

  </div>
  <!--//banner -->
  <!--/single-->
  <div class="container">
 <br>


<?php
// $id = isset($_GET['id']) ? $_GET['id'] : '1';
$id = $_GET['id'] ?? '1'; // PHP > 7.0

$contact = find_contact_by_id($id);

?>
<div id="content">

  
  <div class=" content">

    <h1 align="center">SENDER: <?php echo h($contact['senderName']); ?> </h1> 
    
    <?php echo "<br />";?>
    <p><b>PHONE NUMBER: </b> <?php echo h($contact['emailAddress']); ?></p>

    <?php echo "<br />";?>
    <p><b> EMAIL ADDRESS: </b> <?php echo h($contact['contactPhoneNumber']); ?></p>

   <?php echo "<br />";?>
    
    <p><b>SUBJECT: </b> <?php echo h($contact['subject']); ?></p>

     


    <?php echo "<br />";?>
    <p><b> MESSAGE: </b><?php echo h($contact['message']); ?></p>

   			<br />
   			<p align="center"> <a href="#"><button class="btn-primary" >Print</button> </a> </p>
     <?php echo "<br />";?>
 <p align="right"> <a  href="<?php echo url_for(('admin/feedback.php')); ?>">&laquo; Back to Feedback List</a> </p>
  </div>

</div>

<?php include('../shared/footer.php'); ?>