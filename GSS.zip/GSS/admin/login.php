<?php
session_start();
if (isset($_SESSION['admin'])) {
  echo "<script>window.location= 'index.php';</script>";
}


if(isset($_POST['login'])){
    //print_r($_POST);
    require "connection.php";

  $user = (isset($_POST['Username']) && !empty($_POST['Username'])) ? validateInput($_POST['Username']) : '';
  $pass = (isset($_POST['Password']) && !empty($_POST['Password'])) ? validateInput($_POST['Password']) : '';

  $query_search = "SELECT * FROM user WHERE username = '$user' AND password = '$pass' LIMIT 1";
//echo $query_search;
  $result_search = $db->query($query_search);
  $numSearched = $result_search->num_rows;

if(validInputs()){

  if ($numSearched >= 1) {
    //if admin exist
     $_SESSION['admin'] = $user;
     header("Location: index.php");
 }else{    
     echo "<script>alert('Invalid login credentials provided'); window.location= 'login.php';</script>";
    }


  
 }else{
    echo "<script>alert('Invalid input provided'); window.location= 'login.php';</script>";
 }


}

function addSessionAndLogin($Username){
    echo "string";
}

function validateInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = (strlen($data) >= 2) ? $data : '';
    return $data;
  }

  function validInputs(){
    //are inputs valid?
    global $user;
    global $pass;
  

    if (empty($user) || empty($pass)) {
      #returns a boolean
      return false;
    }
    return true;
  }
?>
<?php  require_once ('../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Login Page';

?>
<?php include( '../shared/staff_header.php'); ?>
    <header id="head" class="secondary">
                <div class="container">
                        <h1>Admin Dashboard </h1>
                        <p> Bring Your Child and Let us give him the best education</p>
                    </div>
        </header>

  <div class="container">
        <div class="row">
          <div class="col-md-8">
            <h3 class="section-title">Login Page</h3>
            
            
<p> <span class="warning"> Please Enter Your Username and Pasword</span></p> 
<form class="form-light mt-20" role="form" action="login.php" method="POST">

    <div class="form-group"> 
      <label for="name" class="mr-sm-2">Username:</label>
    <input type="text" class="form-control" name="Username" required="" value="<?php // echo $register_child['child_surname']; ?>" Placeholder="Username">
    </div>

   <div class="form-group">  <label for="pwd" class="mr-sm-2">Password:</label>
    <input type="text" class="form-control" name="Password" required="" value="<?php //echo $register_child['other_name']; ?>" Placeholder="Password">
  </div>
 <p align="center"> <button type="submit" name="login" class="btn btn-primary mb-2">Login</button> </p>
  </form>

</div>
  <div class="col-sm-6">