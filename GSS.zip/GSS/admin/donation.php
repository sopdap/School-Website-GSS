<?php  require_once ('../../private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Add staff Record';

?>
<?php include(SHARED_PATH . '/admin_header.php'); ?>

	<div class="clearfix"></div>
	</div>
	<!-- banner -->
	<div class="banner-inner-page">

	</div>
	<!--//banner -->
	<!--/single-->
	<div class="container">
 <br>

  <h2>DONATION TABLE</h2>
  <p>Donation promised recieved from our website </p>            
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        
        <th>Email Adress</th>
        <th>Phone Number</th>
        
        <th>Amount Promised</th>
        <th>Action</th>

      </tr>
    </thead>

    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        
        <td>Message</td>
        <td>Email Adress</td>
        
        <td>08112345667</td>
        <td><button class="btn-success">View Details</button> <button class="btn-danger">Delete</button> <button class="btn-primary">Print</button></td>
      </tr>

      <tr>
        <td>Mary</td>
        <td>Moe</td>
        
        <td>Message</td>
        <td>Email Address</td>
        
        <td>08112345667</td>
        <td><button class="btn-success">View Details</button> <button class="btn-danger">Delete</button> <button class="btn-primary">Print</button></td>
      </tr>
      
      <tr>
        <td>July</td>
        <td>Dooley</td>
       
        <td>Message</td>
        <td>Email Address</td>
        
        <td>08112345667</td>
        <td><button class="btn-success">View Details</button> <button class="btn-danger">Delete</button> <button class="btn-primary">Print</button></td>
      </tr>
    </tbody>
  </table>
  
	<!-- footer -->
	<?php include(SHARED_PATH . '/admin_page_footer.php'); ?>