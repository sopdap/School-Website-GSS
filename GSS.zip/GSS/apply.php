<?php include('shared/page_header.php'); ?>

<?php  require_once ('private/initialize.php'); ?>

<?php 

//error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "gssdb";
// Create connection
$output ="";
if(isset($_POST['submit'])){
$conn = new mysqli($servername, $username, $password, $dbName);

$child_full_name = $_POST['child_full_name'];
$DOB = $_POST['DOB'];
$childLevel = $_POST['childLevel'];
$parentName = $_POST['parentName'];
$parentPhoneNumber = $_POST['parentPhoneNumber'];
$contactAddress = $_POST['contactAddress'];
$reason = $_POST['reason'];


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO application (child_full_name, DOB, childLevel, parentName, parentPhoneNumber, contactAddress, reason)
VALUES ('$child_full_name', '$DOB', '$childLevel', '$parentName', '$parentPhoneNumber', '$contactAddress', '$reason')";

if (mysqli_query($conn, $sql)) {   	


  	//echo ('applicationdetails.php?id=' . h(u($application['application_id']))); 

    $output = "Application sumbitted successfullly" . "<a href ='index.php'>Click Here to Go back Home</a>";
   ///Redirect_to(url_for('/applicationdetails.php?id=' . $new_id)); die; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}

?>

	<header id="head" class="secondary">
            <div class="container">
                    <h1>Application </h1>
                    <p> Bring Your Child and Let us give him the best education</p>
                </div>
    </header>


	<!-- container -->
	<div class="container">
				<div class="row">
					<div class="col-md-8">
						<h3 class="section-title">Child Details</h3>
						<h3 class="section-title"><span style="color: green"><?php echo $output; ?></span></h3>
						<p>
						Please fill the form below appropriate, and upon submitted come with print out and word.
						</p>
						
						<form class="form-light mt-20" role="form" action="apply.php" method="post">
							<div class="form-group">
								<label>Name</label>
								<input type="text" class="form-control" placeholder="Your name" name="child_full_name" required="">
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Date of Birth</label>
										<input type="date" class="form-control" placeholder="Date Of Birth" name="DOB" required="">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Current Class</label>
										<select Class="form-control" name="childLevel" required="">
											<option value=""> Select Current Child Class</option>
											<option value="Primary One"> Primary One</option>
											<option value="Primary Two"> Primary Two</option>
											<option value="Primary Three"> Primary Three</option>
											<option value="Primary Four"> Primary Four</option>
											<option value="Primary Five"> Primary Five</option>

										</select>
										
									</div>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Parent Name</label>
										<input type="text" class="form-control" placeholder="Parent Name" name="parentName" required="">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Parent Phone Number</label>
										<input type="text" class="form-control" placeholder="Parent Phone number" name="parentPhoneNumber" required="">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label>Contact Address</label>
								<input type="text" class="form-control" placeholder="Contact Address" name="contactAddress" required="">
							</div>
							<div class="form-group">
								<label>Why Do you Choose this school</label>
								<textarea class="form-control" id="message" placeholder="Write you reason here..." style="height:100px;" name="reason" required=""></textarea>
							</div>
							<button type="submit" class="btn btn-two" name="submit">Apply</button><p><br/></p>
						</form>
					</div>
					<div class="col-md-4">
						<div class="row">
							<div class="col-md-6">
								<h3 class="section-title">Our Location</h3>
								<div class="contact-info">
									<h5>Address</h5>
									<p>Along Jos Road, Ombi 1, Lafia</p>
									
									<h5>Email</h5>
									<p>adminssion@gsslafia.com</p>
									
									<h5>Phone</h5>
									<p>+2348160413494</p>
									<h5>Post Address</h5>
									<p>PMB BOX 1234567</p>
								</div>
							</div> 
						</div> 						
					</div>
				</div>
			</div>
	<!-- /container -->
<?php include('shared/footer.php'); ?>

