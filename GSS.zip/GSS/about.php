<?php include('shared/page_header.php'); ?>

 	<header id="head" class="secondary">
            <div class="container">
                    <h1>About Us</h1>
                
                </div>
    </header>


    <!-- container -->
    <section class="container">
        <div class="row">
            <!-- main content -->
            <section class="col-sm-8 maincontent">
                <h3>About Us</h3>
                <p align="justify">
                    <img src="assets/images/about.png" alt="" class="img-rounded pull-right" width="300">
                  Government Secondary School, Lafia is a start-up in 19987 under the governor company consisting of three principle officers with combined industry experience of 40 years. The company was formed to take advantage of the perceived weakness and inadequacies of other regional companies in terms of quality and customer satisfaction. Barnum Painters will be a partnership between Mr. William Barnum, Mr. Anthony Barnum and Mr. Michael Kruger. The principles in the company will be investing significant amounts of their own capital into the company and will also be seeking a loan to cover start-up costs and future growth.
                Barnum Painters will be located in a rented suite in the Rucker Industrial Park on 710 Snoquamie Route, Suite 250 in Edmonds, WA. The facilities will include a reception area, offices for the principals, storage area for inventory, and employee lounge.
                
                The company plans to use its existing contacts and the combined customer base of Mr.'s Barnum and Kruger to generate short-term residential contracts. Its long-term profitability will rely on focusing on commercial contracts that will be obtained through strategic alliances and a comprehensive marketing program.

                </p>
                
            </section>
            <!-- /main -->

            <!-- Sidebar -->
            <aside class="col-sm-4 sidebar sidebar-right">

                <div class="panel">
                    <h4>Latest News</h4>
                    <ul class="list-unstyled list-spaces">
                        <li><a href="">PTA Meeting</a><br>
                            <span class="small text-muted">Their will be PTA Meeting on 30th of Novenmber, 2018</span></li>
                        <li><a href="">Chrisman Holiday</a><br>
                            <span class="small text-muted">Christmas Holiday Start on 15th December, 2018</span></li>
                      
                    </ul>
                </div>

            </aside>
            <!-- /Sidebar -->

        </div>
    </section>
    <!-- /container -->
   
  <?php include('shared/footer.php'); ?>
