
<?php  require_once ('private/initialize.php'); ?>

<?php
   //include('../../private/shared/session.php');
   $page_title = 'Admin Dashboard';

?>
<?php include('shared/page_header.php'); ?>

    <header id="head" class="secondary">
                <div class="container">
                        <h1>Application Detail  </h1>
                        
                    </div>
        </header>

<div class="clearfix"></div>
  </div>
  <!-- banner -->
  <div class="banner-inner-page">

  </div>
  <!--//banner -->
  <!--/single-->
  <div class="container">
 <br>
<?php
// $id = isset($_GET['id']) ? $_GET['id'] : '1';
$id = $_GET['id'] ?? '1'; // PHP > 7.0

$application = find_application_by_id($id);

?>
<div class="container">

   <div class="row">
  <div class="col-sm-12">
 

   <pre> 
    <h1 align="center">My NAME is <?php echo h($application['child_full_name']); ?> </h1> 
    <h3> <b>I ws born on the : </b> <?php echo h($application['DOB']); ?></p> 
    <p> <b>I am currently in Level: </b> <?php echo h($application['childLevel']); ?></p>
    <p><b>My Parent/Guidian Name is </b> <?php echo h($application['parentName']); ?> , <b> and you can reach him through </b> <?php echo h($application['parentPhoneNumber']); ?></p>
    <p><b> Our house is located at: </b> <?php echo h($application['contactAddress']); ?></p>
    <p><b> The reason </b> I want my child  to join your honourable school is that:  <?php echo h($application['reason']); ?></p>
    <p> Thank you for favaourable consider my application.

                  <p align="right">Your Faithfully</p> 
                  <p align="right"> Sign Guidian <?php echo h($application['parentName']); ?></p>

  
</pre>
    
        
  </div>




        <h3 align="center"> <button class="btn-success" onClick="window.print()" >Print The Appliacation Details</button> </h3>
     <?php echo "<br />";?>
 <p align="right"> <a  href="<?php echo url_for(('admin/applicationPrint.php')); ?>">&laquo; Back to Feedback List</a> </p>



</div>
</div>

<?php include(SHARED_PATH . '/admin_page_footer.php'); ?>